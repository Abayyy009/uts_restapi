

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Daftar Sekolah</h1>
    <a href="<?php echo e(route('sekolah.create')); ?>" class="btn btn-primary">Tambah Sekolah</a>
    <table class="table mt-3">
        <tr>
            <th>Nama</th><th>Alamat</th><th>Aksi</th>
        </tr>
        <?php $__currentLoopData = $sekolahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($s->nama); ?></td>
            <td><?php echo e($s->alamat); ?></td>
            <td>
                <a href="<?php echo e(route('sekolah.edit', $s->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                <form action="<?php echo e(route('sekolah.destroy', $s->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button onclick="return confirm('Yakin?')" class="btn btn-danger btn-sm">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sig-sekolah\resources\views\index.blade.php ENDPATH**/ ?>